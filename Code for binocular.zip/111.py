import pandas as pd

path = r"F:\\CJ_Stere_Vision\\csv_file\\3d_data\\12.15.8.csv"
file = pd.read_csv(path)
file.to_csv('1.csv',encoding='utf-8',index=False)
print(file)