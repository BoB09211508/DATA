import numpy as np
import pandas as pd
### 读取csv文件 观察右侧肘关节的角度变化
import math
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error as mse
from sklearn import metrics

# df_op = pd.read_csv('11.30.9_cleaned_duiqi.csv')[:390]
# df_op = pd.read_csv('Angles//2.20.2.4_Angle.csv')
# df_az = pd.read_csv('F:\CJ_Stere_Vision\\test\\12.5\单独与度量对比\\Azure2 vs duliang.csv')
# df_k2 = pd.read_csv('test//12.15//Kinect9.csv')
df_du = pd.read_csv('test/3.9/SD_New/duliang3.9.3.3.csv')

Angle_du1 = []
Angle_du2 = []
Angle_du3 = []
Angle_du4 = []

for i in range(len(df_du)):
    Angle_du1.append(180-df_du['Angle1s_L'][i]) # 左肘 elbow
    Angle_du2.append(180-df_du['Angle2s_L'][i]) # 左肩膀 shoulder
    Angle_du3.append(180-df_du['Angle1s_R'][i])  # 右肘 elbow
    Angle_du4.append(180-df_du['Angle2s_R'][i]) # 右肩膀 shoulder

file = pd.DataFrame({'L_elbow':Angle_du1,'L_shoulder':Angle_du2,'R_elbow':Angle_du3,'R_shoulder':Angle_du4})
print(file)
file.to_csv('Angles//3.9//Du//duliang3.9.3.3.csv')