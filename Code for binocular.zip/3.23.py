import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QLabel
from PyQt5.QtGui import QPixmap
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        # 创建一个QLabel来显示图像
        self.label = QLabel(self)
        self.setCentralWidget(self.label)

        # 创建3D图形
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        x, y, z = [1, 2, 3], [4, 5, 6], [7, 8, 9]
        ax.scatter(x, y, z)

        # 将图像转换为QPixmap并设置给QLabel
        canvas = fig.canvas
        canvas.draw()
        size = canvas.size()
        self.label.setPixmap(QPixmap(canvas.buffer_rgba()).scaled(size.width(), size.height()))

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    app.exec_()
