# coding=gbk
# coding:utf-8
import numpy as np
# import cv2
#
# def bm_disparity_map(left_img, right_img, block_size=7, num_disparities=720):
#     # ��������ͼ�ĻҶ�ͼ��
#     left_gray = cv2.cvtColor(left_img, cv2.COLOR_BGR2GRAY)
#     right_gray = cv2.cvtColor(right_img, cv2.COLOR_BGR2GRAY)
#
#     # ʹ��SGBM�㷨�����ʼ���Ӳ�ͼ
#     stereo = cv2.StereoBM_create(numDisparities=num_disparities, blockSize=block_size)
#     disparity = stereo.compute(left_gray, right_gray)
#
#     # ���Ӳ�ͼ���д�����������ֵ��Χ��һ����[0, 255]
#     disparity = cv2.normalize(disparity, disparity, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_8U)
#
#     return disparity
#
# imgl_rectified = cv2.imread('new_pic_jiaozheng/test/Person/left/5.26_left_person1.jpg')
# imgr_rectified = cv2.imread('new_pic_jiaozheng/test/Person/right/5.26_right_person1.jpg')
#
# dis = bm_disparity_map(imgl_rectified,imgr_rectified)
# cv2.imwrite('BM.jpg',dis)

## 2
import cv2

left_image = cv2.imread('new_pic_jiaozheng/cut/2.27/SK/left8/Image_20230227154332801.jpg',0)
right_image = cv2.imread('new_pic_jiaozheng/test/Person/right/5.26_right_person1.jpg',0)

# StereoBM�㷨��������
stereo = cv2.StereoBM_create(numDisparities=880, blockSize=7)

# �����Ӳ�ͼ
disparity = stereo.compute(left_image, right_image)

# �����˲���
kernel = np.ones((5, 5), np.float32) / 25
filtered_disparity = cv2.filter2D(disparity, -1, kernel)

# ��ʾ�Ӳ�ͼ���˲���Ľ��
cv2.imshow("Disparity", disparity)
cv2.imshow("Filtered Disparity", filtered_disparity)
cv2.imwrite('BM_1.jpg',disparity)
cv2.imwrite('BM_2.jpg',filtered_disparity)
cv2.waitKey(0)
cv2.destroyAllWindows()

## 3
# import cv2
# import numpy as np

# BM�㷨��������ƥ��
# left_image = cv2.imread('new_pic_jiaozheng/test/Person/left/5.26_left_person1.jpg',0)
# right_image = cv2.imread('new_pic_jiaozheng/test/Person/right/5.26_right_person1.jpg',0)
# stereo = cv2.StereoBM_create(numDisparities=64, blockSize=15)
# disparity = stereo.compute(left_image, right_image)
#
# # ����wls�˲���
# wls_filter = cv2.ximgproc.createDisparityWLSFilter(stereo)
# wls_filter.setLambda(3000.0)
# wls_filter.setSigmaColor(0.8)
#
# # ����wls�˲�
# filtered_disp = wls_filter.filter(disparity, left_image, None, right_image)
#
# # ��һ�����ͼ��
# normalized_disp = cv2.normalize(filtered_disp, None, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_8U)
#
# # ��ʾ���ͼ��
# cv2.imshow('Disparity Map', normalized_disp)
# cv2.imwrite('1.jpg',normalized_disp)
# cv2.waitKey()
# cv2.destroyAllWindows()