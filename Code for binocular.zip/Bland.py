import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import matplotlib.font_manager as font_manager

# Generate some data
# x = np.array([1, 2, 3, 4, 5])
# y1 = np.array([0.9, 1.2, 1.1, 1.3, 1.0])
# y2 = np.array([0.8, 1.3, 1.0, 1.2, 1.1])
#
# Calculate the mean difference and standard deviation of the differences
# mean_diff = np.mean(y1 - y2)
# std_diff = np.std(y1 - y2)
#
# Create the Bland-Altman plot
# plt.scatter((y1 + y2) / 2, y1 - y2, color='blue')
# plt.axhline(mean_diff, color='red')
# plt.axhline(mean_diff + 1.96 * std_diff, linestyle='--', color='gray')
# plt.axhline(mean_diff - 1.96 * std_diff, linestyle='--', color='gray')
#
# # Add title and labels
# plt.title('Bland-Altman Plot')
# plt.xlabel('Mean of two measurements')
# plt.ylabel('Difference between two measurements')
#
# # Add legends
# plt.plot([], [], color='blue', label='Data')
# plt.axhline(mean_diff, color='red', label='Mean Difference')
# plt.axhline(mean_diff + 1.96 * std_diff, linestyle='--', color='gray', label='95% Limits of Agreement')
# plt.axhline(mean_diff - 1.96 * std_diff, linestyle='--', color='gray')
#
# plt.legend(loc= 'best') # 设置标签的位置
#
# plt.show()

font = font_manager.FontProperties(fname=r"c:\windows\fonts\simsun.ttc", size=12)

# Generate some data
# opdata = pd.read_csv('Angles/3.15/SA/3.15.3.5_Angle.csv')['L_shoulder'] # elbow shoulder
opdata = pd.read_csv('Angles/3.20/SA/3.20.3.2_Angle.csv')['R_elbow'][:] # elbow shoulder
length = len(opdata)
oplen = length
kinectdata = pd.read_csv('Angles/3.20/Azure/Azure_Angle3.2.csv')['R_elbow'][15:oplen+15]
# kinectdata = pd.read_csv('Angles/3.15/Kinect/Kinect_Angle1.1.csv')['L_shoulder'][10:oplen+10]

print(opdata)
print(kinectdata)

y1 = np.array(opdata)
# y2 = np.array(kinectdata[:oplen])
y2 = np.array(kinectdata[:])

# Calculate the mean difference and standard deviation of the differences
mean_diff= np.mean(y1-y2)
std_diff = np.std(y1-y2)

# 定义列表将差值、平均值等存入其中
up = [mean_diff + 1.96 * std_diff]*oplen
down = [mean_diff - 1.96 * std_diff]*oplen
mean = [mean_diff]*oplen
zeroline = [0]*oplen
x = ((y1 + y2) / 2).tolist()
y = (y1 - y2).tolist()

print("平均差值为：{}".format(mean_diff))

# data = pd.DataFrame({'up':up,'down':down,'mean':mean,'zeroline':zeroline,'x':x,'y':y})
# data.to_csv('LS.csv')

# Create the Bland-Altman plot
plt.scatter((y1 + y2) / 2, y1 - y2, s=20, facecolor='none', edgecolor='black')
plt.axhline(mean_diff, color='black', label='Mean Difference',linestyle=':',linewidth=2)
plt.axhline(mean_diff + 1.96 * std_diff, linestyle='-', color='red', linewidth=2,label='95% Limits of Agreement')
plt.axhline(mean_diff - 1.96 * std_diff, linestyle='-', color='red', linewidth=2)
plt.axhline(0, color='black', linewidth = 2,linestyle='-', label='Zero line')

# plt.text(0.5, mean_diff + 1.96 * std_diff, '1.96', ha='center', va='bottom', color='gray')
# plt.text(0.5, mean_diff - 1.96 * std_diff, '-1.96', ha='center', va='top', color='gray')


print(mean_diff + 1.96 * std_diff)
print(mean_diff - 1.96 * std_diff)
print(mean_diff)

# Add title and labels
plt.title('Bland-Altman图',fontproperties=font)
plt.xlabel('双目系统与Kinect系统的平均值',fontproperties=font)
plt.ylabel('两套系统的差值',fontproperties=font)

# Add legends
# plt.plot([], [], color='blue', label='Data')


# plt.legend(loc= 'best', alpha=0) # 设置标签的位置

plt.legend(loc='best', framealpha=0) # 设置标签位置以及透明度

plt.show()


from sklearn.metrics import mean_squared_error as mse
from sklearn import metrics

data1 = np.array(opdata)
pre1 = np.array(kinectdata)

mse_AB = mse(data1, pre1)
rmse_AB =(mse(data1, pre1)) ** 0.5
mae_AB = metrics.mean_absolute_error(data1, pre1)

def mape(y_true, y_pred):
    return np.mean(np.abs((y_pred - y_true) / y_true)) * 100
mape_AB = mape(data1,pre1)

print("均方根误差RMSE为：{}".format(rmse_AB))
print("平均误差百分比MAPE为：{}".format(mape_AB))
print("平均绝对误差MAE为：{}".format(mae_AB))
