import cv2
import numpy as np
import time
start = time.time()
import matplotlib.pyplot as plt


imgl = cv2.imread('pic/cut/11.10/left2/Image_345.jpg',0)
imgr = cv2.imread('pic/cut/11.10/right2/Image_345.jpg',0)

print(imgl.shape)

# cv2.imwrite('dis_pic//11.14.jpg', disl)
# opencv 展现直方图
# hist = cv2.calcHist([imgl], [0], None, [256], [0, 255])
# plt.plot(hist, color='r')
# plt.show()

# plt展示直方图
# plt.hist(imgr.ravel(),256)
# plt.show()

# 进行直方图的均衡化
equ = cv2.equalizeHist(imgl)
plt.figure("1")
plt.hist(imgl.ravel(), 256)
plt.figure("2")
plt.hist(equ.ravel(), 256)
plt.show()
cv2.imshow('origin',imgl)
cv2.imshow('result',equ)
cv2.waitKey(0)
end = time.time()
print(end-start)