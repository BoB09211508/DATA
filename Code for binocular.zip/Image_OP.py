# coding=gbk
# coding:utf-8
import pyopenpose as op
import matplotlib.pyplot as plt
import cv2
import numpy as np
import pandas as pd
import time

start = time.time()

params = dict()
params["model_folder"] = "models/"
params["net_resolution"] = "368x256" # ���ͷֱ��ʴ���ͼƬ

opWrapper = op.WrapperPython()
opWrapper.configure(params)
opWrapper.start()

imageToProcess = cv2.imread('F:/Jim/CJ_Stere_Vision/new_pic_jiaozheng/cut/3.28/left1.jpg') # ��ȡ������Ҫ������ͼƬ

imageToProcess = cv2.cvtColor(imageToProcess, cv2.COLOR_RGB2BGR)

datum = op.Datum()
datum.cvInputData = imageToProcess
opWrapper.emplaceAndPop(op.VectorDatum([datum]))

# print("Body keypoints: \n" + str(datum.poseKeypoints[0]))

liebiao = list()
arr = datum.poseKeypoints[0]
print(arr)
arr = np.int64(arr) # ��Ԫ��ȡ�� �������� np.round
lie = arr.tolist() # ת����list�б�����

for i in range(0,len(lie)):
    l = list(lie[i][0:2])
    # print(l)
    # l = list(reversed(l))
    liebiao.append(l)
# print(liebiao)

name = ['X-axis','Y-axis']
file = pd.DataFrame(columns=name,data=liebiao)
# ���������ļ������� xxx.csv
file.to_csv('3.28_person.csv',encoding='utf-8',index_label='Keypoints')
end = time.time()
print(end-start)

plt.imshow(datum.cvOutputData)
plt.show()