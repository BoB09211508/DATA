# coding=gbk
# coding:utf-8
import numpy as np
import cv2
import openpyxl

# ��/������ڲ�������ת��ƽ�ƾ���
leftIntrinsic = np.array([[533.9634, 0, 342.6315],
                          [0, 533.9448, 234.3696],
                          [0, 0, 1]])
leftRotation = np.array([[1, 0, 0],
                         [0, 1, 0],
                         [0, 0, 1]])
leftTranslation = np.array([[0],
                            [0],
                            [0]])
rightIntrinsic = np.array([[537.6219, 0, 326.7537],
                           [0, 537.2332, 250.4047],
                           [0, 0, 1]])
rightRotation = np.array([[1, -0.0033, -0.0055],
                          [0.0033, 1, 0.0094],
                          [0.0054, -0.0094, 0.9999]])
rightTranslation = np.array([[-33.2347],
                             [0.4254],
                             [0.0085]])

# ��������Ϊ������Ƭͬ������������꣬��ȡ��ʽ�������
# lx��lyΪ�����ĳ���������꣬rx��ryΪ�������Ӧ����������
def uvToXYZ(lx, ly, rx, ry):
    mLeft = np.hstack([leftRotation, leftTranslation])
    mLeftM = np.dot(leftIntrinsic, mLeft)
    mRight = np.hstack([rightRotation, rightTranslation])
    mRightM = np.dot(rightIntrinsic, mRight)
    A = np.zeros(shape=(4, 3))
    for i in range(0, 3):
        A[0][i] = lx * mLeftM[2, i] - mLeftM[0][i]
    for i in range(0, 3):
        A[1][i] = ly * mLeftM[2][i] - mLeftM[1][i]
    for i in range(0, 3):
        A[2][i] = rx * mRightM[2][i] - mRightM[0][i]
    for i in range(0, 3):
        A[3][i] = ry * mRightM[2][i] - mRightM[1][i]
    B = np.zeros(shape=(4, 1))
    for i in range(0, 2):
        B[i][0] = mLeftM[i][3] - lx * mLeftM[2][3]
    for i in range(2, 4):
        B[i][0] = mRightM[i - 2][3] - rx * mRightM[2][3]
    XYZ = np.zeros(shape=(3, 1))
    # ���ݴ��еķ�����������С���˷�����ռ�����
    cv2.solve(A, B, XYZ, cv2.DECOMP_SVD)
    print(XYZ)
    return XYZ


xyz = uvToXYZ(244.4273987, 94.16474152, 127.9022751, 110.3449249)
print(xyz)

# excel_path = 'D:/SA/AngularPointCoordinates.xlsx'
# if os.path.exists(excel_path) is False:
#     workbook = openpyxl.Workbook()
#     worksheet = workbook.active
#     worksheet.title = 'data'
#     workbook.save(excel_path)
# workbook = openpyxl.load_workbook(excel_path)
# sheet = workbook['data']
# for i in range(0, len(corners1)):
#     sheet.cell(i+1, 1, corners11[i][0][0])
#     sheet.cell(i+1, 2, corners11[i][0][1])
#     sheet.cell(i+1, 3, corners21[i][0][0])
#     sheet.cell(i+1, 4, corners21[i][0][1])
# workbook.save(excel_path)