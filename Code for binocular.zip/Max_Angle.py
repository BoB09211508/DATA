# coding=gbk
# coding:utf-8
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import matplotlib.font_manager as font_manager

opdata = pd.read_csv('Angles/3.15/SA/3.15.3.5_Angle.csv')['R_elbow'] # elbow shoulder
length = len(opdata)
kinectdata = pd.read_csv('Angles/3.15/Azure/Azure_Angle3.5.csv')['R_elbow'][10:]
# �ⲿȡ��Сֵ
print(min(opdata)-min(kinectdata))
# �粿ȡ���ֵ
# print(max(opdata)-max(kinectdata))
