import numpy as np
import pandas as pd
### 读取csv文件 观察右侧肘关节的角度变化
import math

# op vs duliang/Nokov Nokov金标准量程
file = 'Angles/3.9/Du/duliang3.9.3.3.csv'
Nokov_le = pd.read_csv(file)['L_elbow'][15:]
Nokov_ls = pd.read_csv(file)['L_shoulder'][15:]
Nokov_re = pd.read_csv(file)['R_elbow'][15:]
Nokov_rs = pd.read_csv(file)['R_shoulder'][15:]
# 量程
print(max(Nokov_le)-min(Nokov_le))
print(max(Nokov_ls)-min(Nokov_ls))
print(max(Nokov_re)-min(Nokov_re))
print(max(Nokov_rs)-min(Nokov_rs))


# op vs Azure Azure金标准量程
# A_file = 'Angles/2.27/Azure/Azure_Angle3.3.csv'
# Azure_le = pd.read_csv(A_file)['L_elbow'][8:]
# Azure_ls = pd.read_csv(A_file)['L_shoulder'][8:]
# Azure_re = pd.read_csv(A_file)['R_elbow'][8:]
# Azure_rs = pd.read_csv(A_file)['R_shoulder'][8:]
#
# # 量程
# print(max(Azure_le)-min(Azure_le))
# print(max(Azure_ls)-min(Azure_ls))
# print(max(Azure_re)-min(Azure_re))
# print(max(Azure_rs)-min(Azure_rs))



# op vs Kinect Kinect金标准量程
# K_file = 'Angles/2.27//Kinect/Kinect_Angle3.3.csv'
#
# K_le = pd.read_csv(K_file)['L_elbow'][3:]
# K_ls = pd.read_csv(K_file)['L_shoulder'][3:]
# K_re = pd.read_csv(K_file)['R_elbow'][3:]
# K_rs = pd.read_csv(K_file)['R_shoulder'][3:]
#
# # 量程
# print(max(K_le)-min(K_le))
# print(max(K_ls)-min(K_ls))
# print(max(K_re)-min(K_re))
# print(max(K_rs)-min(K_rs))