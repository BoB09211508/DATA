import numpy as np
import pandas as pd
from scipy import stats
import math


# 首先，生成一组预测值和实际值的数据
# predict = np.array([1, 2, 3, 4, 5])
# actual = np.array([1.2, 1.8, 3.5, 4.1, 5.5])
# file_p = pd.read_csv('test/1.csv')['L_elbow'][:430]
# file_a = pd.read_csv('test/2.csv')['L_elbow'][:430]
# # print(file_p)
# # print(file_a)
#
# predict = np.array(file_p)
# actual = np.array(file_a)
#
# print(actual)
#
# # 然后，计算预测值和实际值之间的差异
# errors = actual - predict
#
# # 接下来，计算测量标准误差（SEM）
# sem = np.sqrt(np.mean(errors**2))
#
# # 最后，输出结果
# print("测量标准误差（SEM）为：", sem)



# 首先，生成一组测量结果数据
file_p = pd.read_csv('test/1.csv')['L_elbow'][:430]
file_a = pd.read_csv('test/2.csv')['L_elbow'][:430]
measurements_p = np.array(file_p)
measurements_a = np.array(file_a)

# 然后，计算测量结果的标准差和信度系数
sd1 = np.std(measurements_p)
sd2 = np.std(measurements_a)
alpha = 0.95

# 接下来，计算测量标准误差（SEM）
sem1 = sd1 * np.sqrt(1 - alpha)
sem2 = sd2 * np.sqrt(1 - alpha)

MDC1 = sem1*math.sqrt(2)*1.96
MDC2 = sem2*math.sqrt(2)*1.96

# 使用scipy.stats模块计算SEM
sem_scipy1 = stats.sem(measurements_p) * np.sqrt(1 - alpha)
sem_scipy2 = stats.sem(measurements_a) * np.sqrt(1 - alpha)

# 最后，输出结果
print("测量标准误差（SEM）为：", sem1)
print("使用scipy.stats计算SEM的值为：", sem_scipy1)

print("测量标准误差（SEM）为：", sem2)
print("使用scipy.stats计算SEM的值为：", sem_scipy2)

print(MDC1)
print(MDC2)


