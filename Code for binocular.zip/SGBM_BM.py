# coding=gbk
# coding:utf-8
import cv2
import sys
import numpy as np
import stereo_config
import math
import pandas as pd
import time
import copy

# �Ӳ����
def stereoMatchSGBM_(left_image, right_image, down_scale=False):
    # SGBMƥ���������
    if left_image.ndim == 2:
        img_channels = 1
    else:
        img_channels = 3

    blockSize = 7

    paraml = {'minDisparity': 0,
              # 'numDisparities': 448, # ����
              'numDisparities': 720,  # ����
              'blockSize': blockSize,
              'P1': 8 * img_channels * blockSize ** 2,
              'P2': 32 * img_channels * blockSize ** 2,
              'disp12MaxDiff': 200,  # Ĭ����-1
              'preFilterCap': 15,  # 10~15����
              'uniquenessRatio': 3,  # ����
              'speckleWindowSize': 100,
              'speckleRange': 30,
              'mode': cv2.STEREO_SGBM_MODE_SGBM_3WAY
              }

    # ����SGBM����
    left_matcher = cv2.StereoSGBM_create(**paraml)
    paramr = paraml
    paramr['minDisparity'] = -paraml['numDisparities']
    right_matcher = cv2.StereoSGBM_create(**paramr)

    # ����wls�˲�������
    lmbda = 25000 # ƽ���̶�
    sigma = 0.6 # ��ɫȨ��

    # ����DisparityWLSFilter����
    wls_filter = cv2.ximgproc.createDisparityWLSFilter(matcher_left=left_matcher)

    # ����wls�˲����Ĳ���
    wls_filter.setLambda(lmbda)
    wls_filter.setSigmaColor(sigma)

    # �����Ӳ�ͼ
    size = (left_image.shape[1], left_image.shape[0])
    if down_scale == False:
        disparity_left = left_matcher.compute(left_image, right_image)
        disparity_right = right_matcher.compute(right_image, left_image)

    else:
        left_image_down = cv2.pyrDown(left_image)
        right_image_down = cv2.pyrDown(right_image)
        factor = left_image.shape[1] / left_image_down.shape[1]

        disparity_left_half = left_matcher.compute(left_image_down, right_image_down)
        disparity_right_half = right_matcher.compute(right_image_down, left_image_down)
        disparity_left = cv2.resize(disparity_left_half, size, interpolation=cv2.INTER_AREA)
        disparity_right = cv2.resize(disparity_right_half, size, interpolation=cv2.INTER_AREA)
        disparity_left = factor * disparity_left
        disparity_right = factor * disparity_right

    # ����wls�˲�
    filtered_disp = wls_filter.filter(disparity_left, left_image, None, disparity_right)

    # �����ͼ���׼����ת��Ϊuint8����
    filtered_disp = cv2.normalize(src=filtered_disp, dst=filtered_disp, beta=0, alpha=255, norm_type=cv2.NORM_MINMAX)
    filtered_disp = np.uint8(filtered_disp)

    return filtered_disp


def stereoMatchSGBM(left_image, right_image, down_scale=False):
    # SGBMƥ���������
    if left_image.ndim == 2:
        img_channels = 1
    else:
        img_channels = 3

    blockSize = 7

    paraml = {'minDisparity': 0,
              # 'numDisparities': 448, # ����
              'numDisparities': 720, # ����
              'blockSize': blockSize,
              'P1': 8 * img_channels * blockSize ** 2,
              'P2': 32 * img_channels * blockSize ** 2,
              'disp12MaxDiff': 200, # Ĭ����-1
              'preFilterCap': 15, # 10~15����
              'uniquenessRatio': 4, # ����
              'speckleWindowSize': 100,
              'speckleRange': 30,
              'mode': cv2.STEREO_SGBM_MODE_SGBM_3WAY
              }
    # 8\*number_of_image_channels\*SADWindowSize\*SADWindowSize

    # ����SGBM����
    left_matcher = cv2.StereoSGBM_create(**paraml)
    paramr = paraml
    paramr['minDisparity'] = -paraml['numDisparities']
    right_matcher = cv2.StereoSGBM_create(**paramr)

    # FILTER Parameters
    # lmbda = 80000
    # sigma = 1.2
    # visual_multiplier = 1.0
    #
    # wls_filter = cv2.ximgproc.createDisparityWLSFilter(matcher_left=left_matcher)
    # wls_filter.setLambda(lmbda)
    # wls_filter.setSigmaColor(sigma)

    # """
    #  ����wls�˲�
    #  """
    # FILTER Parameters
    # lmbda = 150000 # ����
    # sigma = 3 # ���� ���������
    # visual_multiplier = 1.0
    #
    # wls_filter = cv2.ximgproc.createDisparityWLSFilter(matcher_left=left_matcher)
    # wls_filter.setLambda(lmbda)
    # wls_filter.setSigmaColor(sigma)


    # �����Ӳ�ͼ
    size = (left_image.shape[1], left_image.shape[0])
    if down_scale == False:
        disparity_left = left_matcher.compute(left_image, right_image)
        disparity_right = right_matcher.compute(right_image, left_image)

    else:
        left_image_down = cv2.pyrDown(left_image)
        right_image_down = cv2.pyrDown(right_image)
        factor = left_image.shape[1] / left_image_down.shape[1]

        disparity_left_half = left_matcher.compute(left_image_down, right_image_down)
        disparity_right_half = right_matcher.compute(right_image_down, left_image_down)
        disparity_left = cv2.resize(disparity_left_half, size, interpolation=cv2.INTER_AREA)
        disparity_right = cv2.resize(disparity_right_half, size, interpolation=cv2.INTER_AREA)
        disparity_left = factor * disparity_left
        disparity_right = factor * disparity_right

    # filteredImg = wls_filter.filter(trueDisp_left, left_image, None, trueDisp_right)  # important to put "imgL" here!!!
    #
    # filteredImg = cv2.normalize(src=filteredImg, dst=filteredImg, beta=0, alpha=255, norm_type=cv2.NORM_MINMAX);
    # filteredImg = np.uint8(filteredImg)
    #
    # # return trueDisp_left,trueDisp_right,img_channels
    # return filteredImg


    # ��ʵ�Ӳ��ΪSGBM�㷨�õ����Ӳ��ǡ�16�ģ�
    trueDisp_left = disparity_left.astype(np.float32) / 16.
    trueDisp_right = disparity_right.astype(np.float32) / 16.

    return trueDisp_left, trueDisp_right


if __name__ == '__main__':
    imgl_rectified = cv2.imread('new_pic_jiaozheng/cut/2.27/SK/left8/Image_20230227154332801.jpg')
    imgr_rectified = cv2.imread('new_pic_jiaozheng/cut/2.27/SK/right8/Image_20230227154332730.jpg')

    disl= stereoMatchSGBM_(imgl_rectified, imgr_rectified, False)
    # disl, disr= stereoMatchSGBM(imgl_rectified, imgr_rectified, False)

    # cv2.imwrite('dis_pic//3.1.jpg', disl)
    cv2.imwrite('dis_pic//3.1.1.jpg', disl)