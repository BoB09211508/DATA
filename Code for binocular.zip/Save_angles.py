import numpy as np
import pandas as pd
### 读取csv文件 观察右侧肘关节的角度变化
import math
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error as mse
from sklearn import metrics

# df_op = pd.read_csv('test//3.9//SA_New//3.9.3.2.csv')
df_op = pd.read_csv('test//3.28//SA_New//3.28.3.5.csv')
df_az = pd.read_csv('test//3.28//SA_New//Azure3.5.csv')
# df_k2 = pd.read_csv('test//3.9//SK//Kinect3.3.csv')
df_k2 = pd.read_csv('test//3.15//SK_New//Kinect3.5.csv')
df_du = pd.read_csv('test//3.9//SD_New//duliang3.9.3.3.csv')
print(df_op)
# print(df_k2)
print(df_az)
# print(df_du)

# print(df_op[10:430])
# print(df_du[10:430])

length_op = len(df_op)
length_az = len(df_az)
length_k2 = len(df_k2)
length_du = len(df_du)
# print(length)

def cal_angle(point_a, point_b, point_c):
    """
    根据三点坐标计算夹角

                  点a
           点b ∠
                   点c

    :param point_a、point_b、point_c: 数据类型为list,二维坐标形式[x、y]或三维坐标形式[x、y、z]
    :return: 返回角点b的夹角值


    数学原理：
    设m,n是两个不为0的向量，它们的夹角为<m,n> (或用α ,β, θ ,..,字母表示)

    1、由向量公式：cos<m,n>=m.n/|m||n|

    2、若向量用坐标表示，m=(x1,y1,z1), n=(x2,y2,z2),

    则,m.n=(x1x2+y1y2+z1z2).

    |m|=√(x1^2+y1^2+z1^2), |n|=√(x2^2+y2^2+z2^2).

    将这些代入②得到：

    cos<m,n>=(x1x2+y1y2+z1z2)/[√(x1^2+y1^2+z1^2)*√(x2^2+y2^2+z2^2)]

    上述公式是以空间三维坐标给出的，令坐标中的z=0,则得平面向量的计算公式。

    两个向量夹角的取值范围是：[0,π].

    夹角为锐角时，cosθ>0；夹角为钝角时,cosθ<0.

    """
    a_x, b_x, c_x = point_a[0], point_b[0], point_c[0]  # 点a、b、c的x坐标
    a_y, b_y, c_y = point_a[1], point_b[1], point_c[1]  # 点a、b、c的y坐标

    if len(point_a) == len(point_b) == len(point_c) == 3:
        # print("坐标点为3维坐标形式")
        a_z, b_z, c_z = point_a[2], point_b[2], point_c[2]  # 点a、b、c的z坐标
    else:
        a_z, b_z, c_z = 0,0,0  # 坐标点为2维坐标形式，z 坐标默认值设为0
        # print("坐标点为2维坐标形式，z 坐标默认值设为0")

    # 向量 m=(x1,y1,z1), n=(x2,y2,z2)
    x1,y1,z1 = (a_x-b_x),(a_y-b_y),(a_z-b_z)
    x2,y2,z2 = (c_x-b_x),(c_y-b_y),(c_z-b_z)

    # 两个向量的夹角，即角点b的夹角余弦值
    cos_b = (x1*x2 + y1*y2 + z1*z2) / (math.sqrt(x1**2 + y1**2 + z1**2) *(math.sqrt(x2**2 + y2**2 + z2**2))) # 角点b的夹角余弦值
    B = math.degrees(math.acos(cos_b)) # 角点b的夹角值
    return B

OP1 = []
OP2 = []
OP3 = []
OP4 = []
OP5 = []
OP6 = []
OP7 = []
OP8 = []
OP9 = []
OP10 = []
OP11 = []
OP12 = []

AZ1 = []
AZ2 = []
AZ3 = []
AZ4 = []
AZ5 = []
AZ6 = []
AZ7 = []
AZ8 = []
AZ9 = []
AZ10 = []
AZ11 = []
AZ12 = []

K1 = []
K2 = []
K3 = []
K4 = []
K5 = []
K6 = []
K7 = []
K8 = []
K9 = []
K10 = []
K11 = []
K12 = []

# 存储最终的角度
Angle_op1 = []
Angle_op2 = []
Angle_op3 = []
Angle_op4 = []

Angle_az1 = []
Angle_az2 = []
Angle_az3 = []
Angle_az4 = []


Angle_k1 = []
Angle_k2 = []
Angle_k3 = []
Angle_k4 = []

Angle_du = []

ans_op = 0
ans_az = 0
ans_k2 = 0
ans_du = 0

# openpose
# R_Shoulder 6 7 8 R_Elbow 9 10 11 R_Wrist 12 13 14
# print(df[Keypoints[14]][0])
# Keypoints = ['Nose X', 'Nose Y', 'Nose Z', 'Neck X', 'Neck Y', 'Neck Z', 'Rshoulder X', 'Rshoulder Y','Rshoulder Z', 'RElbow X', 'RElbow Y', 'RElbow Z', 'RWrist X', 'RWrist Y', 'RWrist Z','LShoulder X', 'LShoulder Y', 'LShoulder Z', 'LElbow X', 'LElbow Y', 'LElbow Z', 'LWrist X','LWrist Y', 'LWrist Z', 'MidHip X',
#             'MidHip Y','MidHip Z','RHip X','RHip Y','RHip Z','RKnee X','RKnee Y','RKnee Z','RAnkle X','RAnkle Y','RAnkle Z','LHip X','LHip Y','LHip Z','LKnee X','LKnee Y','LKnee Z','LAnkle X','LAnkle Y','LAnkle Z','REye X','REye Y','REye Z','LEye X','LEye Y',
#             'LEye Z','REar X','REar Y','REar Z','LEar X','LEar Y','LEar Z','LBigToe X','LBigToe Y','LBigToe Z','LSmallToe X','LSmallToe Y','LSmallToe Z','LHeel X','LHeel Y','LHeel Z','RBigToe X','RBigToe Y','RBigToe Z','RSmallToe X','RSmallToe Y','RSmallToe Z','RHeel X','RHeel Y','RHeel Z']

Keypoints = ['Nose X', 'Nose Y', 'Nose Z', 'Neck X', 'Neck Y', 'Neck Z', 'Rshoulder X', 'Rshoulder Y',
                 'Rshoulder Z', 'RElbow X', 'RElbow Y', 'RElbow Z', 'RWrist X', 'RWrist Y', 'RWrist Z', 'LShoulder X',
                 'LShoulder Y', 'LShoulder Z', 'LElbow X', 'LElbow Y', 'LElbow Z', 'LWrist X', 'LWrist Y', 'LWrist Z',
                 'MidHip X','MidHip Y', 'MidHip Z', 'RHip X', 'RHip Y', 'RHip Z', 'RKnee X', 'RKnee Y', 'RKnee Z', 'LHip X', 'LHip Y', 'LHip Z', 'LKnee X', 'LKnee Y', 'LKnee Z']


for i in range(length_op):
    # 左肘部
    OP1.append(df_op[Keypoints[15]][i])
    OP1.append(df_op[Keypoints[16]][i])
    OP1.append(df_op[Keypoints[17]][i])

    OP2.append(df_op[Keypoints[18]][i])
    OP2.append(df_op[Keypoints[19]][i])
    OP2.append(df_op[Keypoints[20]][i])

    OP3.append(df_op[Keypoints[21]][i])
    OP3.append(df_op[Keypoints[22]][i])
    OP3.append(df_op[Keypoints[23]][i])

    # 左肩部
    OP4.append(df_op[Keypoints[6]][i])
    OP4.append(df_op[Keypoints[7]][i])
    OP4.append(df_op[Keypoints[8]][i])

    OP5.append(df_op[Keypoints[15]][i])
    OP5.append(df_op[Keypoints[16]][i])
    OP5.append(df_op[Keypoints[17]][i])

    OP6.append(df_op[Keypoints[18]][i])
    OP6.append(df_op[Keypoints[19]][i])
    OP6.append(df_op[Keypoints[20]][i])

    # 左肩部新 颈部中间
    # OP4.append(df_op[Keypoints[3]][i])
    # OP4.append(df_op[Keypoints[4]][i])
    # OP4.append(df_op[Keypoints[5]][i])
    #
    # OP5.append(df_op[Keypoints[15]][i])
    # OP5.append(df_op[Keypoints[16]][i])
    # OP5.append(df_op[Keypoints[17]][i])
    #
    # OP6.append(df_op[Keypoints[18]][i])
    # OP6.append(df_op[Keypoints[19]][i])
    # OP6.append(df_op[Keypoints[20]][i])

    # 右肘部
    OP7.append(df_op[Keypoints[6]][i])
    OP7.append(df_op[Keypoints[7]][i])
    OP7.append(df_op[Keypoints[8]][i])

    OP8.append(df_op[Keypoints[9]][i])
    OP8.append(df_op[Keypoints[10]][i])
    OP8.append(df_op[Keypoints[11]][i])

    OP9.append(df_op[Keypoints[12]][i])
    OP9.append(df_op[Keypoints[13]][i])
    OP9.append(df_op[Keypoints[14]][i])

    # 右肩部
    OP10.append(df_op[Keypoints[15]][i])
    OP10.append(df_op[Keypoints[16]][i])
    OP10.append(df_op[Keypoints[17]][i])

    OP11.append(df_op[Keypoints[6]][i])
    OP11.append(df_op[Keypoints[7]][i])
    OP11.append(df_op[Keypoints[8]][i])

    OP12.append(df_op[Keypoints[9]][i])
    OP12.append(df_op[Keypoints[10]][i])
    OP12.append(df_op[Keypoints[11]][i])

    # 右肩部新 颈部
    # OP10.append(df_op[Keypoints[3]][i])
    # OP10.append(df_op[Keypoints[4]][i])
    # OP10.append(df_op[Keypoints[5]][i])
    #
    # OP11.append(df_op[Keypoints[6]][i])
    # OP11.append(df_op[Keypoints[7]][i])
    # OP11.append(df_op[Keypoints[8]][i])
    #
    # OP12.append(df_op[Keypoints[9]][i])
    # OP12.append(df_op[Keypoints[10]][i])
    # OP12.append(df_op[Keypoints[11]][i])



    # 列表转换成元组格式
    a1 = tuple(OP1)
    b1 = tuple(OP2)
    c1 = tuple(OP3)
    ans_op1 = cal_angle(a1, b1, c1) # 左肘部

    a2 = tuple(OP4)
    b2 = tuple(OP5)
    c2 = tuple(OP6)
    ans_op2 = cal_angle(a2, b2, c2) # 左肩部


    a3 = tuple(OP7)
    b3 = tuple(OP8)
    c3 = tuple(OP9)
    ans_op3 = cal_angle(a3, b3, c3) # 右肘部


    a4 = tuple(OP10)
    b4 = tuple(OP11)
    c4 = tuple(OP12)
    ans_op4 = cal_angle(a4, b4, c4) # 右肩部

    # Angle_op1.append(180-ans_op1) # 肘部
    Angle_op1.append(ans_op1) # 肘部
    Angle_op2.append(ans_op2) # 肩部
    # Angle_op3.append(180 - ans_op3)  # 肘部
    Angle_op3.append(ans_op3)  # 肘部
    Angle_op4.append(ans_op4)  # 肩部

    # print(a)
    # print(b)
    # print(c)

    OP1.clear()
    OP2.clear()
    OP3.clear()
    OP4.clear()
    OP5.clear()
    OP6.clear()
    OP7.clear()
    OP8.clear()
    OP9.clear()
    OP10.clear()
    OP11.clear()
    OP12.clear()

# file = pd.DataFrame({'L_elbow':Angle_op1,'L_shoulder':Angle_op2,'R_elbow':Angle_op3,'R_shoulder':Angle_op4})
# file.to_csv('Angles//3.28//SA//3.28.3.5_Angle.csv')


# print(Angle_op)
# print(len(Angle_op))

# Azure Kinect
# R_Shoulder 38 39 40 R_Elbow 41 42 43 R_Wrist 44 45 46
Keypoints = ['ShoulderRight X','ShoulderRight Y','ShoulderRight Z','ElbowRight X','ElbowRight Y','ElbowRight Z', 'WristRight X','WristRight Y','WristRight Z',
             'ShoulderLeft X','ShoulderLeft Y','ShoulderLeft Z','ElbowLeft X','ElbowLeft Y','ElbowLeft Z','WristLeft X', 'WristLeft Y','WristLeft Z']
for i in range(length_az):
    # 左肘部
    AZ1.append(df_az[Keypoints[9]][i])
    AZ1.append(df_az[Keypoints[10]][i])
    AZ1.append(df_az[Keypoints[11]][i])

    AZ2.append(df_az[Keypoints[12]][i])
    AZ2.append(df_az[Keypoints[13]][i])
    AZ2.append(df_az[Keypoints[14]][i])

    AZ3.append(df_az[Keypoints[15]][i])
    AZ3.append(df_az[Keypoints[16]][i])
    AZ4.append(df_az[Keypoints[17]][i])

    # 左肩部
    AZ4.append(df_az[Keypoints[0]][i])
    AZ4.append(df_az[Keypoints[1]][i])
    AZ4.append(df_az[Keypoints[2]][i])

    AZ5.append(df_az[Keypoints[9]][i])
    AZ5.append(df_az[Keypoints[10]][i])
    AZ5.append(df_az[Keypoints[11]][i])

    AZ6.append(df_az[Keypoints[12]][i])
    AZ6.append(df_az[Keypoints[13]][i])
    AZ6.append(df_az[Keypoints[14]][i])

    # 右肘部
    AZ7.append(df_az[Keypoints[0]][i])
    AZ7.append(df_az[Keypoints[1]][i])
    AZ7.append(df_az[Keypoints[2]][i])

    AZ8.append(df_az[Keypoints[3]][i])
    AZ8.append(df_az[Keypoints[4]][i])
    AZ8.append(df_az[Keypoints[5]][i])

    AZ9.append(df_az[Keypoints[6]][i])
    AZ9.append(df_az[Keypoints[7]][i])
    AZ9.append(df_az[Keypoints[8]][i])

    # 右肩膀
    AZ10.append(df_az[Keypoints[9]][i])
    AZ10.append(df_az[Keypoints[10]][i])
    AZ10.append(df_az[Keypoints[11]][i])

    AZ11.append(df_az[Keypoints[0]][i])
    AZ11.append(df_az[Keypoints[1]][i])
    AZ11.append(df_az[Keypoints[2]][i])

    AZ12.append(df_az[Keypoints[3]][i])
    AZ12.append(df_az[Keypoints[4]][i])
    AZ12.append(df_az[Keypoints[5]][i])



    # 列表转换成元组格式
    az1 = tuple(AZ1)
    bz1 = tuple(AZ2)
    cz1 = tuple(AZ3)
    ans_az1 = cal_angle(az1, bz1, cz1)

    az2 = tuple(AZ4)
    bz2 = tuple(AZ5)
    cz2 = tuple(AZ6)
    ans_az2 = cal_angle(az2, bz2, cz2)

    az3 = tuple(AZ7)
    bz3 = tuple(AZ8)
    cz3 = tuple(AZ9)
    ans_az3 = cal_angle(az3, bz3, cz3)


    az4 = tuple(AZ10)
    bz4 = tuple(AZ11)
    cz4 = tuple(AZ12)
    ans_az4 = cal_angle(az4, bz4, cz4)




    Angle_az1.append(ans_az1)
    Angle_az2.append(180-ans_az2)
    Angle_az3.append(ans_az3)
    Angle_az4.append(ans_az4)

    # print(a)
    # print(b)
    # print(c)

    AZ1.clear()
    AZ2.clear()
    AZ3.clear()
    AZ4.clear()
    AZ5.clear()
    AZ6.clear()
    AZ7.clear()
    AZ8.clear()
    AZ9.clear()
    AZ10.clear()
    AZ11.clear()
    AZ12.clear()

# data = pd.DataFrame({'L_elbow':Angle_az1,'L_shoulder':Angle_az2,'R_elbow':Angle_az3,'R_shoulder':Angle_az4})
# data.to_csv('Angles//3.28//Azure//Azure_Angle3.5.csv')

print(len(Angle_az1))

# Kinect V2
# R_Shoulder 38 39 40 R_Elbow 41 42 43 R_Wrist 44 45 46
Keypoints = ['Shoulder Right X','Shoulder Right Y','Shoulder Right Z','Elbow Right X','Elbow Right Y','Elbow Right Z', 'Wrist Right X', 'Wrist Right Y', 'Wrist Right Z',
             'Shoulder Left X','Shoulder Left Y','Shoulder Left Z','Elbow Left X','Elbow Left Y','Elbow Left Z', 'Wrist Left X', 'Wrist Left Y', 'Wrist Left Z',
             'Spine Shoulder X', 'Spine Shoulder Y', 'Spine Shoulder Z']
for i in range(length_k2):
    # 左肘部 elbow
    K1.append(df_k2[Keypoints[9]][i])
    K1.append(df_k2[Keypoints[10]][i])
    K1.append(df_k2[Keypoints[11]][i])

    K2.append(df_k2[Keypoints[12]][i])
    K2.append(df_k2[Keypoints[13]][i])
    K2.append(df_k2[Keypoints[14]][i])

    K3.append(df_k2[Keypoints[15]][i])
    K3.append(df_k2[Keypoints[16]][i])
    K3.append(df_k2[Keypoints[17]][i])

    # 左肩 shoulder
    K4.append(df_k2[Keypoints[0]][i])
    K4.append(df_k2[Keypoints[1]][i])
    K4.append(df_k2[Keypoints[2]][i])

    K5.append(df_k2[Keypoints[9]][i])
    K5.append(df_k2[Keypoints[10]][i])
    K5.append(df_k2[Keypoints[11]][i])

    K6.append(df_k2[Keypoints[12]][i])
    K6.append(df_k2[Keypoints[13]][i])
    K6.append(df_k2[Keypoints[14]][i])

    # 右肘部 elbow
    K7.append(df_k2[Keypoints[0]][i])
    K7.append(df_k2[Keypoints[1]][i])
    K7.append(df_k2[Keypoints[2]][i])

    K8.append(df_k2[Keypoints[3]][i])
    K8.append(df_k2[Keypoints[4]][i])
    K8.append(df_k2[Keypoints[5]][i])

    K9.append(df_k2[Keypoints[6]][i])
    K9.append(df_k2[Keypoints[7]][i])
    K9.append(df_k2[Keypoints[8]][i])



    # 右肩膀 shoulder
    K10.append(df_k2[Keypoints[9]][i])
    K10.append(df_k2[Keypoints[10]][i])
    K10.append(df_k2[Keypoints[11]][i])

    K11.append(df_k2[Keypoints[0]][i])
    K11.append(df_k2[Keypoints[1]][i])
    K11.append(df_k2[Keypoints[2]][i])

    K12.append(df_k2[Keypoints[3]][i])
    K12.append(df_k2[Keypoints[4]][i])
    K12.append(df_k2[Keypoints[5]][i])


    # 列表转换成元组格式
    ak1 = tuple(K1)
    bk1 = tuple(K2)
    ck1 = tuple(K3)
    ans_k1 = cal_angle(ak1, bk1, ck1)

    ak2 = tuple(K4)
    bk2 = tuple(K5)
    ck2 = tuple(K6)
    ans_k2 = cal_angle(ak2, bk2, ck2)

    ak3 = tuple(K7)
    bk3 = tuple(K8)
    ck3 = tuple(K9)
    ans_k3 = cal_angle(ak3, bk3, ck3)

    ak4 = tuple(K10)
    bk4 = tuple(K11)
    ck4 = tuple(K12)
    ans_k4 = cal_angle(ak4, bk4, ck4)

    Angle_k1.append(ans_k1)
    Angle_k2.append(ans_k2)
    Angle_k3.append(ans_k3)
    Angle_k4.append(ans_k4)


    K1.clear()
    K2.clear()
    K3.clear()
    K4.clear()
    K5.clear()
    K6.clear()
    K7.clear()
    K8.clear()
    K9.clear()
    K10.clear()
    K11.clear()
    K12.clear()

# shuju = pd.DataFrame({'L_elbow':Angle_k1,'L_shoulder':Angle_k2,'R_elbow':Angle_k3,'R_shoulder':Angle_k4})
# shuju.to_csv('Angles//3.20//Kinect//Kinect_Angle3.5.csv')

# 度量直接有数据
for i in range(len(df_du)):
    Angle_du.append(180-df_du['Angle1s_L'][i]) # 左肘 elbow
    # Angle_du.append(180-df_du['Angle2s_L'][i]) # 左肩膀 shoulder
    # Angle_du.append(180-df_du['Angle1s_R'][i])  # 右肘 elbow
    # Angle_du.append(180-df_du['Angle2s_R'][i]) # 右肩膀 shoulder

x1, x2, x3, x4 = [], [], [], []
for i in range(length_op):
# for i in range(280):
    x1.append(i)

for i in range(length_az-15):
# for i in range(length_az):
    x2.append(i)

# for i in range(length_k2):
for i in range(length_k2-10):
    x3.append(i)

for i in range(length_du-15):
# for i in range(280):
    x4.append(i)


# print(len(x1))
# 多张图放在一张图
plt.plot(x1, Angle_op4, label="Binocular", color='blue')
plt.plot(x2, Angle_az4[15:], label="Azure", color='green')
# plt.plot(x2, Angle_az4[15:], label="Azure", color='green')
# plt.plot(x3, Angle_k2[10:], label="Kinect V2", color='black')
# plt.plot(x4, Angle_du[15:], label="Nokov", color='red')

print(min(Angle_op1))
print(min(Angle_k1))

# plt.xlabel('Frame')
# plt.ylabel('Angle')

# plt.title('The angle of the left elbow changes diagram')
# plt.title('The angle of the left shoulder changes diagram')
# plt.title('The angle of the right elbow changes diagram')
plt.title('The angle of the right shoulder changes diagram')

plt.legend(loc= 'best') # 设置标签的位置
plt.ylim(60, 180) # 限制坐标轴的大小
# plt.ylim(60, 180) # 限制坐标轴的大小 # 肩部
# # plt.ylim(0, 120) # 限制坐标轴的大小 # 肘部
plt.show()



# 预测值与实际值进行比较
# data1 = np.array(Angle_op4[:])
# pre1 = np.array(Angle_k4[16:])

# data1 = np.array(Angle_op4[200:410])
# pre1 = np.array(Angle_az4[215:425])


# data1 = np.array(Angle_op1[:])
# pre1 = np.array(Angle_du[35:length_op+35])

# data1 = np.array(Angle_op4[:])
# pre1 = np.array(Angle_du[17:])

# print(len(data1))
# print(len(pre1))

# print(Angle_k1[16:])

# mse_AB = mse(data1, pre1)
# rmse_AB =(mse(data1, pre1)) ** 0.5
# mae_AB = metrics.mean_absolute_error(data1, pre1)
#
# def mape(y_true, y_pred):
#     return np.mean(np.abs((y_pred - y_true) / y_true)) * 100
# mape_AB = mape(data1,pre1)
#
# print("均方根误差RMSE为：{}".format(rmse_AB))
# print("平均误差百分比MAPE为：{}".format(mape_AB))
# print("平均绝对误差MAE为：{}".format(mae_AB))

