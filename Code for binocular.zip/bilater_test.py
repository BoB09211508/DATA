import cv2 as cv
import numpy as np
cv.namedWindow("image")
cv.createTrackbar("d","image",0,255)
cv.createTrackbar("sigmaColor","image",0,255)
cv.ctrateTrackbar("sigmaSpace","image",0,255)
img = cv.imread("test.jpg",0)
while(1):
    d = cv.getTrackbarPos("d","image")
    sigmaColor = cv.getTrackbarPos("sigmaColor","image")
    sigmaSpace = cv.getTrackbarPos("sigmaSpace","image")
    out_img = cv.bilateralFilter(img,d,sigmaColor,sigmaSpace)
    cv.imshow("out",out_img)
    k = cv.waitKey(1) & 0xFF
    if k ==27:
        break
    cv.destroyAllWindows()