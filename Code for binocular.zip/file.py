# coding=gbk
# coding:utf-8
import numpy as np
import pandas as pd
import os
import cv2

Keypoints = ['Nose X', 'Nose Y', 'Nose Z', 'Neck X', 'Neck Y', 'Neck Z', 'Rshoulder X', 'Rshoulder Y',
             'Rshoulder Z', 'RElbow X', 'RElbow Y', 'RElbow Z', 'RWrist X', 'RWrist Y', 'RWrist Z', 'LShoulder X',
             'LShoulder Y', 'LShoulder Z', 'LElbow X', 'LElbow Y', 'LElbow Z', 'LWrist X', 'LWrist Y', 'LWrist Z',
             'MidHip X', 'MidHip Y', 'MidHip Z', 'RHip X', 'RHip Y', 'RHip Z', 'RKnee X', 'RKnee Y', 'RKnee Z',
             'LHip X', 'LHip Y', 'LHip Z', 'LKnee X', 'LKnee Y', 'LKnee Z']

# ������Ҫ�������ļ�ѡ��
path = r"F:\\Jim\\CJ_Stere_Vision\\csv_file\\3d_data\\3.28.3.5.csv"
file = pd.read_csv(path)
length = file.shape[0]
print(length)

data = file[Keypoints[3]]
print(data)

Count = []
Sum = []
# for i in range(75):
for i in range(39):
    count = 0 # ͳ��0�ĸ���
    sum = 0  # �ܺ�
    data = file[Keypoints[i]]
    for j in range(len(data)):
        if abs(data[j]) > 5000:
            data[j] = 0
            count += 1
        sum += data[j]
    Count.append(count)
    Sum.append(sum)


# print(len(Count))
# print(len(Sum))
# print(Count)
# print(Sum)

# for i in range(75):
for i in range(39):
    data = file[Keypoints[i]]
    res = Sum[i]
    count = Count[i]
    for j in range(len(data)):
        # print(len(data))
        if data[j] == 0:
            data[j] = res/(length-count)
            # print(data[j])

# ָ���ļ��л�·�����漴��
file.to_csv('3.28.3.5.csv')