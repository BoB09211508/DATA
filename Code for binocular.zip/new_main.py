# coding=gbk
# coding:utf-8
# coding=gbk
# coding:utf-8
# ������Ҫ�İ���ģ��
from PyQt5.Qt import *  # ��Ҫ�����˳��õ�һЩ�� ������һ��
from PyQt5 import QtCore, QtGui, QtWidgets
from resources.video_capture_new import Ui_Form  # ����py�ļ�
import cv2
from PyQt5.QtCore import *
from PyQt5.QtCore import QTimer
from PyQt5.QtGui import QImage, QPixmap
import time
import os
from datetime import datetime
import sys
import threading
import numpy as np

sys.path.append("../MvImport")
from MvCameraControl_class import *

fourcc = cv2.VideoWriter_fourcc(*'XVID')



# ���������1�ı���·���߳�
class Thread1(QThread):

    def __init__(self, *args, **kwargs):
        super().__init__()
        self.active = True
        self.cap0 = cv2.VideoCapture(1)
        self.cap0.set(cv2.CAP_PROP_FRAME_WIDTH, 3072)  # ����ͼ�����
        self.cap0.set(cv2.CAP_PROP_FRAME_HEIGHT, 2048)  # ����ͼ��߶�

    def run(self):
        if self.active:
            self.path1 = 'resources\\left\\'
            self.out1 = cv2.VideoWriter(
                self.path1 + datetime.now().strftime('%Y-%m-%d__%H-%M-%S') + '.avi', fourcc, 10,
                (3072, 2048))

            while self.active:
                ret1, image1 = self.cap0.read()
                if ret1:
                    self.out1.write(image1)

                self.msleep(2)

    def stop(self):
        self.out1.release()


# ���������2�ı���·���߳�
class Thread2(QThread):

    def __init__(self, *args, **kwargs):
        super().__init__()
        self.active = True
        self.cap1 = cv2.VideoCapture(2)
        self.cap1.set(cv2.CAP_PROP_FRAME_WIDTH, 3072)  # ����ͼ�����
        self.cap1.set(cv2.CAP_PROP_FRAME_HEIGHT, 2048)  # ����ͼ��߶�

    def run(self):
        if self.active:
            self.path2 = 'resources\\right\\'
            self.out2 = cv2.VideoWriter(
                self.path2 + datetime.now().strftime('%Y-%m-%d__%H-%M-%S') + '.avi', fourcc, 10,
                (3072, 2048))

            while self.active:
                ret2, image2 = self.cap1.read()
                if ret2:
                    self.out2.write(image2)

                self.msleep(2)

    def stop(self):
        self.out2.release()


class Main(QWidget, Ui_Form):
    sendAddDeviceName = pyqtSignal()  # ����һ�������豸�б����źš�
    deviceList = MV_CC_DEVICE_INFO_LIST()
    tlayerType = MV_GIGE_DEVICE | MV_USB_DEVICE

    g_bExit = False
    camera_information = False  # ��ȡ�����־
    opencamera_flay = False  # �������־

    # ch:�������ʵ�� | en:Creat Camera Object
    cam0 = MvCamera()
    cam1 = MvCamera()

    def __init__(self, parent=None, *args, **kwargs):
        super(Main, self).__init__(parent, *args, **kwargs)
        self.setupUi(self)
        self.setWindowTitle("˫Ŀ���ʵʱ��׽ϵͳ")

        self.timer_camera = QtCore.QTimer()  # ��ʾʵʱ�Ķ�ʱ��
        self.saveTimer = QtCore.QTimer()  # ����Ķ�ʱ��
        self.cap0 = cv2.VideoCapture()
        self.cap1 = cv2.VideoCapture()

        self.camera0.setScaledContents(True)
        self.camera1.setScaledContents(True)


        self.th1 = Thread1()
        self.th2 = Thread2()

    def get(self):
        '''ѡ���������õ�������б��У�
                     gige�����Ҫ��� sdk �õ���
                '''
        # �õ�����б�
        # tlayerType = MV_GIGE_DEVICE | MV_USB_DEVICE
        # ch:ö���豸 | en:Enum device
        ret = MvCamera.MV_CC_EnumDevices(self.tlayerType, self.deviceList)
        if ret != 0:
            print("enum devices fail! ret[0x%x]" % ret)
            # QMessageBox.critical(self, '����', '��ȡ�豸����ʧ�ܣ�')
            # sys.exit()
        if self.deviceList.nDeviceNum == 0:
            QMessageBox.critical(self, "����", "û�з����豸 �� ")
            # print("find no device!")
            # sys.exit()
        else:
            QMessageBox.information(self, "��ʾ", "������ %d ���豸 !" % self.deviceList.nDeviceNum)
        # print("Find %d devices!" % self.deviceList.nDeviceNum)
        if self.deviceList.nDeviceNum == 0:
            return None

        for i in range(0, self.deviceList.nDeviceNum):
            mvcc_dev_info = cast(self.deviceList.pDeviceInfo[i], POINTER(MV_CC_DEVICE_INFO)).contents
            if mvcc_dev_info.nTLayerType == MV_GIGE_DEVICE:
                print("\ngige device: [%d]" % i)
                strModeName = ""
                for per in mvcc_dev_info.SpecialInfo.stGigEInfo.chModelName:
                    strModeName = strModeName + chr(per)
                print("device model name: %s" % strModeName)
                self.camSelect.addItem(strModeName, i)  # д���豸�б���

        self.camera_information = True

    def slot_init(self):  # �����ź�
        # self.timer_camera.timeout.connect(self.show_camera0)
        # self.timer_camera.timeout.connect(self.show_camera1)
        pass

    def open_device(self):
        # if self.camera_information == True:
        #     self.g_bExit = False
        #     # ch:ѡ���豸��������� | en:Select device and create handle
        #     stDeviceList = cast(self.deviceList.pDeviceInfo[int(0)], POINTER(MV_CC_DEVICE_INFO)).contents
        #     ret = self.cam0.MV_CC_CreateHandle(stDeviceList)
        #
        #     print(ret)
        #
        #     if ret != 0:
        #         # print("create handle fail! ret[0x%x]" % ret)
        #         QMessageBox.critical(self, "����", "�������ʧ�� ! ret[0x%x]" % ret)
        #         # sys.exit()
        #     # ch:���豸 | en:Open device
        #     ret = self.cam0.MV_CC_OpenDevice(MV_ACCESS_Exclusive, 0)
        #     print(ret)
        #
        #     if ret != 0:
        #         # print("open device fail! ret[0x%x]" % ret)
        #         QMessageBox.critical(self, "����", "���豸ʧ�� ! ret[0x%x]" % ret)
        #         # sys.exit()
        #
        #     # ch:���ô���ģʽΪoff | en:Set trigger mode as off
        #     ret = self.cam0.MV_CC_SetEnumValue("TriggerMode", MV_TRIGGER_MODE_OFF)
        #     print(ret)
        #
        #     if ret != 0:
        #         # print("set trigger mode fail! ret[0x%x]" % ret)
        #         QMessageBox.critical(self, "����", "���ô���ģʽʧ�� ! ret[0x%x]" % ret)
        #         # sys.exit()
        #         # ch:��ȡ���ݰ���С | en:Get payload size
        #     stParam = MVCC_INTVALUE()
        #     memset(byref(stParam), 0, sizeof(MVCC_INTVALUE))
        #
        #     ret = self.cam0.MV_CC_GetIntValue("PayloadSize", stParam)
        #     print(ret)
        #
        #     if ret != 0:
        #         # print("get payload size fail! ret[0x%x]" % ret)
        #         QMessageBox.critical(self, "����", "��ȡ��Ч���ش�Сʧ�� ! ret[0x%x]" % ret)
        #         # sys.exit()
        #     nPayloadSize = stParam.nCurValue
        #
        #     # ch:��ʼȡ�� | en:Start grab image
        #     ret = self.cam0.MV_CC_StartGrabbing()
        #     print(ret)
        #
        #     if ret != 0:
        #         # print("start grabbing fail! ret[0x%x]" % ret)
        #         QMessageBox.critical(self, "����", "��ʼץȡͼ��ʧ�� ! ret[0x%x]" % ret)
        #         # sys.exit()
        #
        #     data_buf = (c_ubyte * nPayloadSize)()
        #     self.opencamera_flay = True
        #     try:
        #         hThreadHandle = threading.Thread(target=self.work_thread0, args=(self.cam0, data_buf, nPayloadSize))
        #         hThreadHandle.start()
        #     except:
        #         # print("error: unable to start thread")
        #         QMessageBox.critical(self, "����", "�޷������߳� ! ")
        #
        # else:
        #     QMessageBox.critical(self, '����', '��ȡ�����Ϣʧ�ܣ�')
        #     return None

        if self.camera_information == True:
            self.g_bExit = False
            # ch:ѡ���豸��������� | en:Select device and create handle
            stDeviceList0 = cast(self.deviceList.pDeviceInfo[int(0)], POINTER(MV_CC_DEVICE_INFO)).contents
            stDeviceList1 = cast(self.deviceList.pDeviceInfo[int(1)], POINTER(MV_CC_DEVICE_INFO)).contents

            ret0 = self.cam0.MV_CC_CreateHandle(stDeviceList0)
            ret1 = self.cam1.MV_CC_CreateHandle(stDeviceList1)

            if ret0 and ret1 != 0:
                # print("create handle fail! ret[0x%x]" % ret)
                QMessageBox.critical(self, "����", "�������ʧ�� ! ret[0x%x]" % ret0)
                # sys.exit()

            # ch:���豸 | en:Open device
            ret0 = self.cam0.MV_CC_OpenDevice(MV_ACCESS_Exclusive, 0)
            ret1 = self.cam1.MV_CC_OpenDevice(MV_ACCESS_Exclusive, 0)

            if ret0 and ret1 != 0:
                # print("open device fail! ret[0x%x]" % ret)
                QMessageBox.critical(self, "����", "���豸ʧ�� ! ret[0x%x]" % ret0)
                # sys.exit()

            # ch:���ô���ģʽΪoff | en:Set trigger mode as off
            ret0 = self.cam0.MV_CC_SetEnumValue("TriggerMode", MV_TRIGGER_MODE_OFF)
            ret1 = self.cam1.MV_CC_SetEnumValue("TriggerMode", MV_TRIGGER_MODE_OFF)


            if ret0 and ret1 != 0:
                # print("set trigger mode fail! ret[0x%x]" % ret)
                QMessageBox.critical(self, "����", "���ô���ģʽʧ�� ! ret[0x%x]" % ret0)
                # sys.exit()
                # ch:��ȡ���ݰ���С | en:Get payload size

            stParam0 = MVCC_INTVALUE()
            stParam1 = MVCC_INTVALUE()

            memset(byref(stParam0), 0, sizeof(MVCC_INTVALUE))
            memset(byref(stParam1), 0, sizeof(MVCC_INTVALUE))

            ret0 = self.cam0.MV_CC_GetIntValue("PayloadSize", stParam0)
            ret1 = self.cam1.MV_CC_GetIntValue("PayloadSize", stParam1)

            if ret0 and ret1 != 0:
                # print("get payload size fail! ret[0x%x]" % ret)
                QMessageBox.critical(self, "����", "��ȡ��Ч���ش�Сʧ�� ! ret[0x%x]" % ret0)
                # sys.exit()
            nPayloadSize0 = stParam0.nCurValue
            nPayloadSize1 = stParam1.nCurValue

            # ch:��ʼȡ�� | en:Start grab image
            ret0 = self.cam0.MV_CC_StartGrabbing()
            ret1 = self.cam1.MV_CC_StartGrabbing()

            if ret0 and ret1 != 0:
                # print("start grabbing fail! ret[0x%x]" % ret)
                QMessageBox.critical(self, "����", "��ʼץȡͼ��ʧ�� ! ret[0x%x]" % ret0)
                # sys.exit()

            data_buf0 = (c_ubyte * nPayloadSize0)()
            data_buf1 = (c_ubyte * nPayloadSize1)()

            self.opencamera_flay = True
            try:
                hThreadHandle0 = threading.Thread(target=self.work_thread0, args=(self.cam0, data_buf0, nPayloadSize0))
                hThreadHandle1 = threading.Thread(target=self.work_thread1, args=(self.cam1, data_buf1, nPayloadSize1))

                hThreadHandle0.start()
                hThreadHandle1.start()
            except:
                # print("error: unable to start thread")
                QMessageBox.critical(self, "����", "�޷������߳� ! ")

        else:
            QMessageBox.critical(self, '����', '��ȡ�����Ϣʧ�ܣ�')
            return None


    def close_Event(self):
        if self.opencamera_flay == True:
            self.g_bExit = True
            # ch:ֹͣȡ�� | en:Stop grab image
            ret0 = self.cam0.MV_CC_StopGrabbing()
            ret1 = self.cam1.MV_CC_StopGrabbing()

            if ret0 and ret1 != 0:
                # print("stop grabbing fail! ret[0x%x]" % ret)
                QMessageBox.critical(self, "����", "ֹͣץȡͼ��ʧ�� ! ret[0x%x]" % ret0)
                # sys.exit()

            # ch:�ر��豸 | Close device
            ret0 = self.cam0.MV_CC_CloseDevice()
            ret1 = self.cam1.MV_CC_CloseDevice()

            if ret0 and ret1 != 0:
                # print("close deivce fail! ret[0x%x]" % ret)
                QMessageBox.critical(self, "����", "ֹͣ�豸ʧ�� ! ret[0x%x]" % ret0)

            # ch:���پ�� | Destroy handle
            ret0 = self.cam0.MV_CC_DestroyHandle()
            ret1 = self.cam1.MV_CC_DestroyHandle()

            if ret0 and ret1 != 0:
                # print("destroy handle fail! ret[0x%x]" % ret)
                QMessageBox.critical(self, "����", "���ٴ���ʧ�� ! ret[0x%x]" % ret0)

            self.camera0.clear()
            self.camera1.clear()

            self.camera0.setText("���ź�")
            self.camera1.setText("���ź�")

            self.camera_information = False
            self.opencamera_flay = False
            QMessageBox.about(self, '��ʾ��', '<h2>�ر�����ɹ���</h2>')
        else:
            QMessageBox.critical(self, '����', 'δ���������')
            return None

    def work_thread0(self, cam=0, pData=0, nDataSize=0):
        stFrameInfo = MV_FRAME_OUT_INFO_EX()
        memset(byref(stFrameInfo), 0, sizeof(stFrameInfo))
        while True:
            ret = cam.MV_CC_GetOneFrameTimeout(pData, nDataSize, stFrameInfo, 1000)
            if ret == 0:
                image = np.asarray(pData)  # ��c_ubyte_Arrayת����ndarray�õ���3686400����
                # print(image.shape)
                image = image.reshape((2048, 3072, 3))  # �����Լ��ֱ��ʽ���ת��
                # image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)  # ��һ����ȡ������ɫ���ԣ���ΪĬ����BRG��Ҫת����RGB����ɫ������
                # image = cv2.cvtColor(image, cv2.COLOR_BAYER_GB2BGR)  # Bayer��ʽ��raw data����RGB��BGR��ɫ�ռ��ת��
                # print(image.shape)
                # pyrD1 = cv2.pyrDown(image)  # ����ȡ��
                # pyrD2 = cv2.pyrDown(pyrD1)  # ����ȡ��
                # image = cv2.resize(image,(640,480))
                # image = cv2.cvtColor(image,cv2.COLOR_BGR2RGB)

                image_height, image_width, image_depth = image.shape  # ��ȡͼ��߿����
                self.image_show0 = QImage(image.data, image_width, image_height, image_width * image_depth,
                                         QImage.Format_RGB888)
                self.camera0.setPixmap(QPixmap.fromImage(self.image_show0))
            if self.g_bExit == True:
                del pData
                break

    def work_thread1(self, cam=1, pData=0, nDataSize=0):
        stFrameInfo = MV_FRAME_OUT_INFO_EX()
        memset(byref(stFrameInfo), 0, sizeof(stFrameInfo))
        while True:
            ret = cam.MV_CC_GetOneFrameTimeout(pData, nDataSize, stFrameInfo, 1000)
            if ret == 0:
                image = np.asarray(pData)  # ��c_ubyte_Arrayת����ndarray�õ���3686400����
                # print(image.shape)
                image = image.reshape((2048, 3072, 3))  # �����Լ��ֱ��ʽ���ת��
                # image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)  # ��һ����ȡ������ɫ���ԣ���ΪĬ����BRG��Ҫת����RGB����ɫ������
                # image = cv2.cvtColor(image, cv2.COLOR_BAYER_GB2BGR)  # Bayer��ʽ��raw data����RGB��BGR��ɫ�ռ��ת��
                # print(image.shape)
                # pyrD1 = cv2.pyrDown(image)  # ����ȡ��
                # pyrD2 = cv2.pyrDown(pyrD1)  # ����ȡ��
                # image = cv2.resize(image, (640, 480))

                image_height, image_width, image_depth = image.shape  # ��ȡͼ��߿����
                self.image_show1 = QImage(image.data, image_width, image_height, image_width * image_depth,
                                         QImage.Format_RGB888)
                self.camera1.setPixmap(QPixmap.fromImage(self.image_show1))
            if self.g_bExit == True:
                del pData
                break

    # ��׽һ֡ͼ��
    def takePhoto(self):
        self.filepath1 = []
        self.filepath2 = []

        if self.opencamera_flay == True:
            now_time = time.strftime('%m-%d-%H-%M-%S', time.localtime(time.time()))
            print(now_time)

            self.filepath1 = 'resources\\left\\others\\' + str(now_time) + '-left' + '.jpg'
            self.filepath2 = 'resources\\right\\others\\' + str(now_time) + '-right' + '.jpg'

            self.image_show0.save(self.filepath1)
            self.image_show1.save(self.filepath2)

            # cv2.imwrite(self.filepath1, self.image_show0)
            # cv2.imwrite(self.filepath2, self.image_show1)
        else:
            QMessageBox.critical(self, '����', '�����δ�򿪣�')
            return None

    # ¼����Ƶ
    def recording(self):
        if not self.saveTimer.isActive():
            self.saveTimer.start()
            self.th1.start()
            self.th2.start()
            self.th1.active = True
            self.th2.active = True
            self.start_video.setText("ֹͣ¼��")
        else:
            self.saveTimer.stop()
            self.th1.active = False
            self.th2.active = False
            self.th1.stop()
            self.th2.stop()
            self.th1.terminate()
            self.th2.terminate()
            self.start_video.setText("��ʼ¼��")
            QMessageBox.about(self, "��ʾ��", "<h2>�ѳɹ�������Ƶ!</h2>")
        pass

    def closeEvent(self, event):
        reply = QMessageBox.question(self, '��ʾ', "ȷ���˳���", QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            event.accept()
            # �ù�sys.exit(0)��sys.exit(app.exec_())����û��Ч��
            os._exit(0)
        else:
            event.ignore()


if __name__ == '__main__':  # �������Դ���Ŀ�ִ����
    import sys

    app = QApplication(sys.argv)

    window = Main()
    window.show()

    sys.exit(app.exec_())