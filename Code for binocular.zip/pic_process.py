# coding=gbk
# coding:utf-8
import pyopenpose as op
import matplotlib.pyplot as plt
import cv2

params = dict()
params["model_folder"] = "models/"
params["net_resolution"] = "368x256" # ���ͷֱ��ʴ���ͼƬ
# params["hand"] = True
# params["number_people_max"] = 1
# params["disable_blending"] = True

# ��ʼ����openpose
opWrapper = op.WrapperPython()
opWrapper.configure(params)
opWrapper.start()

imageToProcess = cv2.imread('caixukun.jpg')
imageToProcess = cv2.cvtColor(imageToProcess,cv2.COLOR_RGB2BGR)

# plt.imshow(imageToProcess)

# ����ͼƬ
datum = op.Datum()
datum.cvInputData = imageToProcess
opWrapper.emplaceAndPop(op.VectorDatum([datum]))

# չʾͼƬ
print('Body keypoints: \n' + str(datum.poseKeypoints))
plt.imshow(datum.cvOutputData)
plt.show()