# coding=gbk
# coding:utf-8

import pandas as pd

df = pd.read_csv('openpose//6.10_person2.csv')

# Nose = points_3d[630,1821].tolist()

print(df['Y-axis'][0],df['X-axis'][0])