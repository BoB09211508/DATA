# coding=gbk
# coding:utf-8
import cv2

def video2frame(videos_path, frames_save_path, time_interval):
    '''
    :param videos_path: ��Ƶ�Ĵ��·��
    :param frames_save_path: ��Ƶ�зֳ�֮֡��ͼƬ�ı���·��
    :param time_interval: ������
    :return:
    '''
    vidcap = cv2.VideoCapture(videos_path)
    success, image = vidcap.read()
    count = 0
    while success:
        success, image = vidcap.read()
        image_rot = image
        # image_rot = cv2.rotate(image, cv2.ROTATE_180)
        count += 1
        if count % time_interval == 0:
            cv2.imencode('.jpg', image_rot)[1].tofile(frames_save_path + "/%d.jpg" % count)
        # if image is None:
        #     break
        # if count == 20:
        #   break
    # print(count)

if __name__ == '__main__':
    videos_path = r'2022-08-18-right.avi'
    frames_save_path = r'pic//cut//right//'
    time_interval = 1  # ��һ֡����һ��
    video2frame(videos_path, frames_save_path, time_interval)
