# coding=gbk
# coding:utf-8
# ������Ҫ�İ���ģ��
from PyQt5.Qt import * # ��Ҫ�����˳��õ�һЩ�� ������һ��
from PyQt5 import QtCore, QtGui, QtWidgets
from resources.video_capture import Ui_Form # ����py�ļ�
import cv2
from PyQt5.QtCore import *
from PyQt5.QtCore import QTimer
from PyQt5.QtGui import QImage, QPixmap
import time
import os
from datetime import datetime

fourcc = cv2.VideoWriter_fourcc(*'XVID')

# ���������1�ı���·���߳�
class Thread1(QThread):

    def __init__(self, *args, **kwargs):
        super().__init__()
        self.active = True
        self.cap0 = cv2.VideoCapture(1)
        self.cap0.set(cv2.CAP_PROP_FRAME_WIDTH, 3072)  # ����ͼ�����
        self.cap0.set(cv2.CAP_PROP_FRAME_HEIGHT, 2048)  # ����ͼ��߶�

    def run(self):
        if self.active:
            # �����·��
            self.path1 = 'resources\\left\\'
            # ������ļ��� ����ĳߴ���ԭ�ߴ�һ��
            self.out1 = cv2.VideoWriter(
               self.path1+datetime.now().strftime('%Y-%m-%d__%H-%M-%S')+'.avi', fourcc, 9,
                (3072, 2048))

            while self.active:
                ret1, image1 = self.cap0.read()
                if ret1:
                    self.out1.write(image1)

                self.msleep(1)

    def stop(self):
        self.out1.release()

# ���������2�ı���·���߳�
class Thread2(QThread):

    def __init__(self, *args, **kwargs):
        super().__init__()
        self.active = True
        self.cap1 = cv2.VideoCapture(2)
        self.cap1.set(cv2.CAP_PROP_FRAME_WIDTH, 3072)  # ����ͼ�����
        self.cap1.set(cv2.CAP_PROP_FRAME_HEIGHT, 2048)  # ����ͼ��߶�

    def run(self):
        if self.active:
            self.path2 = 'resources\\right\\'
            self.out2 = cv2.VideoWriter(
                self.path2 + datetime.now().strftime('%Y-%m-%d__%H-%M-%S') + '.avi', fourcc, 9,
                (3072, 2048))

            while self.active:
                ret2, image2 = self.cap1.read()
                if ret2:
                    self.out2.write(image2)

                self.msleep(1)

    def stop(self):
        self.out2.release()

class Main(QWidget,Ui_Form):

    def __init__(self,parent=None,*args,**kwargs):
        super(Main, self).__init__(parent,*args,**kwargs)
        self.setupUi(self)
        self.setWindowTitle("˫Ŀ���ʵʱ��׽ϵͳ")

        self.timer_camera = QtCore.QTimer() # ��ʾʵʱ�Ķ�ʱ��
        self.saveTimer = QtCore.QTimer() # ����Ķ�ʱ��
        self.cap0 = cv2.VideoCapture()
        self.cap1 = cv2.VideoCapture()
        self.CAM_NUM1 = 1
        self.CAM_NUM2 = 2
        self.slot_init()
        self.th1 = Thread1()
        self.th2 = Thread2()


    def slot_init(self): # �����ź�
        self.timer_camera.timeout.connect(self.show_camera0)
        self.timer_camera.timeout.connect(self.show_camera1)

    def get(self):
        pass

    def open_device(self):
        if self.timer_camera.isActive() == False:
            flag1 = self.cap0.open(self.CAM_NUM1, cv2.CAP_DSHOW)
            flag2 = self.cap1.open(self.CAM_NUM2, cv2.CAP_DSHOW)
            if flag1 == False and flag2 == False:
                msg = QtWidgets.QMessageBox.warning(self, u"Warning", u"�������������Ƿ�������ȷ",
                                                    buttons=QtWidgets.QMessageBox.Ok,
                                                    defaultButton=QtWidgets.QMessageBox.Ok)
            else:
                self.timer_camera.start(30)

        else:
            self.timer_camera.stop()
            self.cap0.release()
            self.cap1.release()
            self.camera0.clear()
            self.camera1.clear()

    def close_Event(self):
        if self.timer_camera.isActive() != False:
            ok = QtWidgets.QPushButton()
            cacel = QtWidgets.QPushButton()

            msg = QtWidgets.QMessageBox(QtWidgets.QMessageBox.Warning, u"�ر�", u"�Ƿ�رգ�")

            msg.addButton(ok, QtWidgets.QMessageBox.ActionRole)
            msg.addButton(cacel, QtWidgets.QMessageBox.RejectRole)
            ok.setText(u'ȷ��')
            cacel.setText(u'ȡ��')

            if msg.exec_() != QtWidgets.QMessageBox.RejectRole:

                if self.cap0.isOpened() and self.cap1.isOpened():
                    self.cap0.release()
                    self.cap1.release()
                if self.timer_camera.isActive():
                    self.timer_camera.stop()

    # ��׽һ֡ͼ��
    def takePhoto(self):
        self.filepath1 = []
        self.filepath2 = []
        self.count = 0
        if self.timer_camera.isActive() != False:
            now_time = time.strftime('%m-%d-%H-%M-%S',time.localtime(time.time()))
            # now_time = time.strftime('%m-%d-%H-%M',time.localtime(time.time()))
            self.count += 1
            # print(self.count)
            # �ļ��������������
            self.filepath1 = 'resources\\left\\second\\'+str(now_time)+'-left'+'.jpg'
            self.filepath2 = 'resources\\right\\second\\'+str(now_time)+'-right'+'.jpg'
            cv2.imwrite(self.filepath1,self.image1)
            cv2.imwrite(self.filepath2,self.image2)
            # print(self.filepath1)
            # print(self.filepath2)

    # ¼����Ƶ
    def recording(self):
        if not self.saveTimer.isActive():
            self.saveTimer.start()
            self.th1.start()
            self.th2.start()
            self.th1.active = True
            self.th2.active = True
            self.start_video.setText("ֹͣ¼��")
        else:
            self.saveTimer.stop()
            self.th1.active = False
            self.th2.active = False
            self.th1.stop()
            self.th2.stop()
            self.th1.terminate()
            self.th2.terminate()
            self.start_video.setText("��ʼ¼��")
            QMessageBox.about(self, "��ʾ��", "<h2>�ѳɹ�������Ƶ!</h2>")

    def show_camera0(self):
        # camera0
        self.ptime = 0
        self.cap0.set(cv2.CAP_PROP_FRAME_WIDTH, 3072)  # ����ͼ�����
        self.cap0.set(cv2.CAP_PROP_FRAME_HEIGHT, 2048)  # ����ͼ��߶�

        flag1, self.image1 = self.cap0.read()

        # cv2.putText(self.image1, 'camera 0', (10, 70), cv2.FONT_HERSHEY_COMPLEX, 3,
        #             (0, 0, 0), 2)

        show1 = cv2.resize(self.image1, (640, 480))
        show1 = cv2.cvtColor(show1, cv2.COLOR_BGR2RGB)

        self.showImage1 = QtGui.QImage(show1.data, show1.shape[1], show1.shape[0], QtGui.QImage.Format_RGB888)

        self.camera0.setPixmap(QtGui.QPixmap.fromImage(self.showImage1))
        # self.camera0.setScaledContents(True) # ��Ӧlabel�ߴ�

    def show_camera1(self):
        # camera1
        self.cap1.set(cv2.CAP_PROP_FRAME_WIDTH, 3072)  # ����ͼ�����
        self.cap1.set(cv2.CAP_PROP_FRAME_HEIGHT, 2048)  # ����ͼ��߶�

        flag2, self.image2 = self.cap1.read()

        # cv2.putText(self.image2, 'camera 1', (10, 70), cv2.FONT_HERSHEY_COMPLEX, 3,
        #             (0, 0, 0), 2)

        show2 = cv2.resize(self.image2, (640, 480))
        show2 = cv2.cvtColor(show2, cv2.COLOR_BGR2RGB)

        self.showImage2 = QtGui.QImage(show2.data, show2.shape[1], show2.shape[0], QtGui.QImage.Format_RGB888)
        self.camera1.setPixmap(QtGui.QPixmap.fromImage(self.showImage2))
        # self.camera1.setScaledContents(True) # ��Ӧlabel�ߴ�
        


if __name__ == '__main__': # �������Դ���Ŀ�ִ����
    import sys
    app = QApplication(sys.argv)

    window = Main()
    window.show()

    sys.exit(app.exec_())