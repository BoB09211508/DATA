import pyopenpose as op
import matplotlib.pyplot as plt
import cv2

params = dict()
params["model_folder"] = "models/"
params["hand"] = True
params["number_people_max"] = 1
params["disable_blending"] = True

opWrapper = op.WrapperPython()
opWrapper.configure(params)
opWrapper.start()


datum = op.Datum()
cap = cv2.VideoCapture('test.mp4')
fps = cap.get(cv2.CAP_PROP_FPS)
size = (int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)))
framecount = cap.get(cv2.CAP_PROP_FRAME_COUNT)

print("Total frames in this video: \n" + str(framecount))
